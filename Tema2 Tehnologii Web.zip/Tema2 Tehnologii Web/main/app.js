
function addTokens(input, tokens){
    if(typeof input != 'string')
        throw "Invalid input";

    if(input.length<6){
        throw("Input should have at least 6 characters");
    }
    for(var i=0;i<tokens.length;i++){
        if(typeof tokens[i].tokenName!= 'string')
        throw "Invalid array format";
    }

    const nr=input.split('...').length;
    for(let i=0;i<nr-1;i++){
        console.log(tokens)
        input=input.replace('...', '${' + tokens[i].tokenName + '}');
       
    }

    return input;
}
const app = {
    addTokens: addTokens
}

module.exports = app;